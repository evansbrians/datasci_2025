
# Answer key for problem set 3: Counting caterpillars

# question 1 --------------------------------------------------------------

# Before opening your script file for this problem set, change the name of
# the `problem_set_3.R` to "problem_set_3_[last name]_[first name].R" using
# a snake case naming convention. *Note: You will submit this script file 
# as your assignment*.

# question 2 --------------------------------------------------------------

# Open the script file in RStudio and attach the tidyverse metapackage to 
# your current R session.

library(tidyverse)

# question 3 --------------------------------------------------------------

# Read in the file `caterpillars_count.rds` and assign the names of the list
# items to the global environment.

read_rds("data/raw/caterpillars_count.rds") %>% 
  list2env(.GlobalEnv)

# question 4 --------------------------------------------------------------

# Subset the `sites` data frame to where `region` is `DC` (District of
# Columbia), `MD` (Maryland), or `VA` (Virginia) and globally assign the name
# `sites_dmv` to the resultant object.

sites_dmv <-
  sites %>% 
  filter(
    region == "DC" |
    region == "MD" |
    region == "VA"  
  ) 

# question 5 --------------------------------------------------------------

# How many caterpillars has Caterpillars Count counted? Please provide your
# answer as a one-value numeric vector.

observations %>% 
  filter(arthropod == "caterpillar") %>% 
  summarise(
    n = n()
  ) %>% 
  sum()

# question 6 --------------------------------------------------------------

# Create a summary table that displays the number of surveys by year and 
# arrange from the highest to lowest number of surveys per year.

surveys %>% 
  group_by(
    year = year(date)
  ) %>% 
  summarise(
    n = n()
  ) %>% 
  arrange(n)


# question 7 --------------------------------------------------------------

# Subset the survey_locations data frame to records that are located within the
# District of Columbia, Maryland, or Virginia. For full credit, please complete
# this such that:

# * No columns are added to, or removed from, `survey_locations`
# * The `filter` function is not used to subset rows
# * The `select` function is not used to subset columns

sites_filter<-
  sites %>% 
  filter(
    region == "DC" |
      region == "MD" |
      region == "VA"  
  ) %>% 
  pull(site_id )


survey_locations %>% 
  .[.$site_id %in% sites_filter,]

# question 8 --------------------------------------------------------------

# Please generate a summary table that provides the average (mean) number of
# caterpillars observed in "Beat sheet" and "Visual" surveys
# (`observation_method`).

observations %>% 
  left_join(
    surveys %>% 
      select(survey_id , observation_method), 
    by = "survey_id"
  ) %>% 
  filter(
    arthropod == "caterpillar"
  ) %>%
  group_by(observation_method) %>%
  summarize(mean = mean(arthropod_quantity))


# question 9 --------------------------------------------------------------

# Please generate a bar plot that displays the number of surveys conducted
# in the District of Columbia, Maryland, and Virginia in 2024. Plot the data
# such that:

# * Your x-aesthetic is region and is labeled "Region"
# * Your y-axis is labeled “Count”
# * The y-axis ranges from 0 to 2500
# * The plot includes a descriptive title

surveys %>%
  
  # Filter surveys conducted in 2024
  
  filter(year(date) == 2024) %>%
  
  # Join to survey_locations (for site_id)
  
  inner_join(
    survey_locations, 
    by = "branch_id"
    ) %>%
  
  # Join to sites (for region/state information)
  
  inner_join(
    sites, 
    by = "site_id"
    ) %>%
  
  # Keep only relevant states/regions
  filter(
    region %in% c(
      "District of Columbia", 
      "Maryland", 
      "Virginia")) %>%
  
  # Count number of surveys per region
  group_by(region) %>%
  summarise(count = n()) %>%  
ggplot() +
  aes(
    x = region,
    y = count,
    fill = region
  ) +
  geom_bar(stat = "identity", width = 0.6, show.legend = FALSE) +
  scale_fill_manual(
    values =
      c(
        "#4A1D2C",
        "#682779",
        "#DC331B",
        "#F29121"
      )
  ) +
  scale_y_continuous(
    limits = c(0,2500),
    expand = c(0,0)
  ) +
  labs (
    title = "N surveys conducted in District of Columbia, 
    Maryland, and Virginia in 2024",
    x = "Region",
    y = "Count"
  ) +
  theme_light()

# question 10 --------------------------------------------------------------

# Please generate a summary table that provides the total number of arthropods
# counted per state in the District of Columbia, Maryland, and Virginia in 2024.

observations %>%
  
  # Join surveys to get date and branch_id
  
  inner_join(
    surveys, 
    by = "survey_id"
  ) %>%
  
  # Filter for surveys conducted in 2024
  
  filter(year(date) == 2024) %>%
  
  # Join survey_locations to get site_id
  
  inner_join(
    survey_locations,
    by = "branch_id"
  ) %>%
  
  # Join sites to get region information (state)
  inner_join(
    sites, 
    by = "site_id"
  ) %>%
  
  # Filter for the states of interest
  filter(
    region %in% c("DC", "MD", "VA")
  ) %>%
  
  # Summarize the total number of arthropods per state
  group_by(region) %>%
  summarise(total_arthropods = sum(arthropod_quantity, na.rm = TRUE)) %>%
  arrange(desc(total_arthropods))


